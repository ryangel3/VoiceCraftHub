# VoiceCraftHub

VoiceCraftHub — A React + Vite powered platform for international voice training and certifications.  
Programs include Spoken English, Public Speaking (Ofqual regulated), Podcasting, and Vocal Singing with certifications from RSL Awards, Rockschool, and Stage School.  
Inspired by Angela and Roselyn’s enduring educational legacy.